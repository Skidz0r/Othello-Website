const file = require('fs');
const crypto = require('crypto');
const { join } = require('path');
const headers = require("./headers.js").headers;

var account = [];
var rooms = [];



if (file.existsSync("accounts.json")) {
    preencheraccount();
}

function preencheraccount() {
    let data = file.readFileSync("accounts.json");
    if (data.length === 0)
        return;
    let parsedData = JSON.parse(data.toString())["users"];
    for (let i = 0; i < parsedData.length; i++) {
        account.push(parsedData[i]);
    }


}

module.exports.methodPost = function (pathname, request, query, response) {
    switch (pathname) {
        case '/register':
            register(query.nick, query.pass, response);
            break;
        case '/join':
            join(query.group, query.nick, query.pass, response);
            break;
        case '/leave':
            leave(query.game, query.nick, query.pass, response);
            break;
        case '/ranking':
            ranking(response);
            break;
        case '/notify':
            notify(query.game, query.nick, query.pass, query.move, response)
            break;
        default:
            response.writeHead(404, headers.plain);
            response.end();
            break;
    }
}

//register
function register(nick, pass, response) {
    if (nick === null || nick === undefined) {
        response.writeHead(400, headers.plain);
        response.write(JSON.stringify({ error: 'username undefined' }));
        response.end();
        return;
    }
    if (pass === null || pass === undefined) {
        response.writeHead(400, headers.plain);
        response.write(JSON.stringify({ error: 'password undefined' }));
        response.end();
        return;
    }
    if (nick === "" || pass === "") {
        response.writeHead(400, headers.plain);
        response.write(JSON.stringify({ error: 'username and password cant be empty' }));
        response.end();
        return;
    }
    const hash = crypto.createHash('md5').update(pass).digest('hex');

    for (let i = 0; i < account.length; i++) {
        if (nick === account[i].nick && hash === account[i].pass) {
            response.writeHead(200, headers.plain);
            response.write(JSON.stringify({}));
            response.end();
            return;
        }
        if (nick === account[i].nick && hash !== account[i].pass) {
            response.writeHead(401, headers.plain);
            response.write(JSON.stringify({ error: 'password doenst match' }));
            response.end();
            return;
        }
    }
    let newuser = {
        nick: nick,
        pass: hash,
        victories: 0,
        games: 0
    };
    addaccount(newuser);
    response.writeHead(200, headers.plain);
    response.write(JSON.stringify({}));
    response.end();
}

function addaccount(newuser) {
    account.push(newuser);
    let data = {
        users: account
    };
    file.writeFileSync("accounts.json", JSON.stringify(data));
}

//ranking
function ranking(response) {
    insertionsort();
    var ranking = [];
    for (let i = 0; i < account.length; i++) {
        if (i == 10)
            break;
        let ranke = {
            nick: account[i].nick,
            games: account[i].games,
            victories: account[i].victories
        };
        ranking.push(ranke);
    }
    rank = { ranking: ranking };
    response.writeHead(200, headers.plain);
    response.write(JSON.stringify(rank));
    response.end();

}

function insertionsort() {
    for (let i = 1; i < account.length; i++) {
        let key = account[i];
        let j = i - 1;
        while (j >= 0 && account[j].victories < key.victories) {
            account[j + 1] = account[j];
            j = j - 1;
        }
        account[j + 1] = key;
    }

}

//join
function join(group, nick, pass, response) {

    if (name === null || name === undefined) {
        response.writeHead(400, headers.plain);
        response.write(JSON.stringify({ error: "User is undefined" }));
        response.end();
        return;
    }
    if (pass === null || pass === undefined) {
        response.writeHead(400, headers.plain);
        response.write(JSON.stringify({ error: "Password is undefined" }));
        response.end();
        return;
    }
    if (game === null || game === undefined) {
        response.writeHead(400, headers.plain);
        response.write(JSON.stringify({ error: "Game is undefined" }));
        response.end();
        return;
    }
    if (name === "" || pass === "") {
        let answer = JSON.stringify({ error: "User and Password can't be empty" });
        response.writeHead(401, headers.plain);
        response.write(answer);
        response.end();
        return;
    }

    //vericar conta
    //meter pessoa numa sala

    //se sala n existir criar:
    //rooms,push(Game(gamedi9d, nick1, null, black, white, board, nick1, undefined, count, false, "", time, null , null))
    //response.write : gameId, black

    //se sala já existir ver se está cheia if nick2 !== null cheio -> erro
    //else if nick2 === null sala.nick2 = nick
    //response.write: gameId, white

}

//update
//if (games[i].getPlayer1() === name && response1 === null -> reponse1 = response
//if (games[i].getPlayer2() === name && response2 === null -> reponse2 = response


//leave
// apagar posição do array da sala
class Game {
    constructor(gameId, nick1, nick2, color1, color2, board, turn, winner, count, skip, error, time, response1, response2) {
        this.gameId = gameId;
        this.nick1 = nick1;
        this.nick2 = nick2;
        this.color1 = color1;
        this.color2 = color2;
        this.board = board;
        this.turn = turn;
        this.winner = winner;
        this.count = count;
        this.skip = skip;
        this.error = error;
        this.time = time;
        this.response1 = response1;
        this.response2 = response2;
    }

    changeturn() {
        if (turn === nick1) {
            turn = nick2;
        }
        else
            turn = nick1;

    }
    //GameId
    getGameId() {
        return this.gameId;
    }
    setGameId(group) {
        this.gameId = crypto.createHash('md5').update(group).digest('hex');
    }
    // Nick1
    getNick1() {
        return this.nick1;
    }
    setNick1(nick1) {
        this.nick1 = nick1;
    }
    // Nick2
    getNick2() {
        return this.nick2;
    }
    setNick2(nick2) {
        this.nick2 = nick2;
    }
    //Turn
    getTurn() {
        return this.turn;
    }
    setTurn(turn) {
        this.turn = turn;
    }
    //Board
    getBoard() {
        return this.board;
    }
    setBoard(board) {
        this.board = board;
    }
    //Winner
    getWinner() {
        return this.winner;
    }
    setWinner(winner) {
        this.winner = winner;
    }
    //Response1
    getResponse1() {
        return this.response1;
    }
    setResponse1(response1) {
        this.response1 = response1;
    }
    //Response2
    getResponse2() {
        return this.response2;
    }
    setResponse2(response2) {
        this.response2 = response2;
    }
    //Count
    getCount() {
        return this.count;
    }
    setCount(count) {
        this.count = count;
    }
    //time
    getTime() {
        return this.time;
    }
    setTime(time) {
        this.time = time;
    }
    //error
    getError() {
        return this.error;
    }
    setError(error) {
        this.error = error;
    }
    //color1
    getColor1() {
        return this.color1;
    }
    setColor1(color1) {
        this.color1 = color1;
    }
    //color2
    getColor2() {
        return this.color2;
    }
    setColor2(color2) {
        this.color2 = color2;
    }
}
