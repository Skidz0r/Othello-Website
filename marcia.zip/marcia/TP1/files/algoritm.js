/* Dominó - Trabalho Prático 2 TW */

class Peca {
	constructor(left, right) {
		this.left = left;
		this.right = right;
	}
}

var pecas = [];
pecas.length = 28;
var oponente = [];
var user = [];
var jogo = [];
var flag=0; // oponente = 0 && utilizador = 1

// Função inicial
function init() {
	var pos = 0;
	// Insere as peças no monte
	for(var i = 0; i < 7; i++) {
		for(var j = i; j < 7; j++) {
			var piece = new Peca(i, j);
			pecas[pos] = piece;
			pos++;
		}
	}
	var pos_random;
	user = [];
	oponente = [];
	jogo = [];
	// Gera as peças random para o oponente
	for(var i = 0; i < 7; i++) {
		pos_random = Math.floor(Math.random()*pecas.length);
		oponente[i] = pecas[pos_random];
		var elem = document.createElement("span");
		elem.innerHTML = "&#" + 127074;
		document.getElementById("jogo_oponente").appendChild(elem);
		pecas.splice(pos_random, 1);
	}
	// Gera as peças random para o user
	for(var i = 0; i < 7; i++) {
		pos_random = Math.floor(Math.random()*pecas.length);
		user[i] = pecas[pos_random];
		var contas = 127025+user[i].left*7+user[i].right+50;
		var elem = document.createElement("span");
		var idp;
		idp = "" + user[i].left + "" + user[i].right + "";
		elem.setAttribute("id","peca("+idp+")");
		elem.setAttribute("onclick", "jogar("+idp+")");
		elem.innerHTML = "&#" + contas;
		document.getElementById("jogo_utilizador").appendChild(elem);
		pecas.splice(pos_random, 1);
	}
	// Imprimir o monte
	var elem1 = document.createElement("span");
	elem1.setAttribute("onclick", "irMonte()");
	elem1.innerHTML = "&#127074;" + pecas.length;
	document.getElementById("monte").appendChild(elem1);

	// var elem2 = document.createElement("span");
	// elem2.setAttribute("onclick", "Passar_Vez()");
	// document.getElementById("passar").appendChild(elem2);

	var elem3 = document.createElement("span");
	elem3.setAttribute("onclick", "giveUp()");
	document.getElementById("desistir").appendChild(elem3);
}

// Função do Início do jogo
function gameStart() {
	init();
	console.log(user);
	console.log(oponente);
	var max = 0;
	var pos_peca = 0;
	// Determinar a peça maior da mão do oponente
	for(var i = 0; i < 7; i++) {
		if( oponente[i].left + oponente[i].right > max) {
			max = oponente[i].left + oponente[i].right;
			pos_peca = i;
			flag = 0;
		}
	}
	//Determinar a peça maior da mão do user
	for(var i = 0; i < 7; i++) {
		if( user[i].left + user[i].right > max) {
			max = user[i].left + user[i].right;
			pos_peca = i;
			flag = 1;
		}
	}
	var contas;
	var elem;
	if(flag == 0) {
		jogo[0]=oponente[pos_peca];
		contas = 127025+oponente[pos_peca].left*7+oponente[pos_peca].right;
		elem = document.createElement("span");
		if(oponente[pos_peca].left===oponente[pos_peca].right)
			contas+=50;
		elem.innerHTML = "&#" + contas;
		document.getElementById("jogo").appendChild(elem);
		var childs = document.getElementById("jogo_oponente").childNodes;
		var childPos = childs[pos_peca];
		document.getElementById("jogo_oponente").removeChild(childPos);
		oponente.splice(pos_peca, 1);
		flag = 1;
	}
	else {
		jogo[0]=user[pos_peca];
		contas = 127025+user[pos_peca].left*7+user[pos_peca].right;
		if(user[pos_peca].left === user[pos_peca].right)
			contas+=50;
		elem = document.createElement("span");
		elem.innerHTML = "&#" + contas;
		document.getElementById("jogo").appendChild(elem);
		var childs = document.getElementById("jogo_utilizador").childNodes;
		var childPos = childs[pos_peca];
		document.getElementById("jogo_utilizador").removeChild(childPos);
		user.splice(pos_peca, 1);
		flag = 0;
	}
}
gameStart();

// Função para o Utilizador jogar
function jogar(id) {
	if(flag==0) return;

	if(id == "0")
		id = "00";
	if(id == "1")
		id = "01";
	if(id == "2")
		id = "02";
	if(id == "3")
		id = "03";
	if(id == "4")
		id = "04";
	if(id == "5")
		id = "05";
	if(id == "6")
		id = "06";

	console.log("Vez_do_User");
	var children = document.getElementById("jogo_utilizador").childNodes;
	var aux;
	var i;
	for(i=0; i<children.length; i++){
		if(children[i].id === "peca("+id+")") {
			aux=i;
			break;
		}
	}
	var childPos = children[aux];
	var jogada = verifyClick(user[aux],jogo[0].left,jogo[jogo.length-1].right);
	if(jogada == -1)return;

	if(jogada == 2 || jogada == 4){
		var contas;
		if(user[aux].right === user[aux].left)
			contas = 127025+user[aux].left*7+user[aux].right+50;
		else
			contas = 127025+user[aux].right*7+user[aux].left;
		
		var elem = document.createElement("span");
		elem.innerHTML = "&#" + contas;

		if(jogada == 2){
			
			jogo.unshift(new Peca(user[aux].right,user[aux].left));
			document.getElementById("jogo").insertBefore(elem,document.getElementById("jogo").childNodes[0]);
			document.getElementById("jogo_utilizador").removeChild(childPos);
			user.splice(aux,1);
		}
		else if(jogada == 4) {
			
			jogo.push(new Peca(user[aux].right,user[aux].left));
			document.getElementById("jogo").appendChild(elem);
			document.getElementById("jogo_utilizador").removeChild(childPos);
			user.splice(aux,1);
		}
	}

	else if(jogada == 3){
		var contas;
		if(user[aux].right === user[aux].left)
			contas = 127025+user[aux].left*7+user[aux].right+50;
		else
			contas = 127025+user[aux].left*7+user[aux].right;
		var elem = document.createElement("span");
		elem.innerHTML = "&#" + contas;
		jogo.unshift(user[aux]);
		document.getElementById("jogo").insertBefore(elem,document.getElementById("jogo").childNodes[0]);
		document.getElementById("jogo_utilizador").removeChild(childPos);
		user.splice(aux,1);
	}

	else if(jogada == 1){
		var contas;
		if(user[aux].right === user[aux].left)
			contas = 127025+user[aux].left*7+user[aux].right+50;
		else
			contas = 127025+user[aux].left*7+user[aux].right;
		var elem = document.createElement("span");
		elem.innerHTML = "&#" + contas;
		jogo.push(user[aux]);
		document.getElementById("jogo").appendChild(elem);
		document.getElementById("jogo_utilizador").removeChild(childPos);
		user.splice(aux,1);
	}
	aparecer_passar();
	isWinner();
	// flag = 0;
}

// Função para o PC jogar
function jogarPC() {
	if(flag == 1) return;

	console.log("Vez_do_PC");
	var children = document.getElementById("jogo_oponente").childNodes;
	var i, n = 0;
	console.log(children.length);
	for(i=0; i<children.length; i++) {
		if(verifyClick(children[i], jogo[0].left, jogo[jogo.length-1].right) != -1) 
			break;
		n++;
	}
	// Ir ao monte
	if(n == children.length) {
		while(pecas.length > 0){ // ir buscar monte
			document.getElementById("monte").innerHTML = "";
			document.getElementById("monte").innerHTML = "&#127074;" + pecas.length;
			var pos_random = Math.floor(Math.random()*pecas.length);
			if(verifyClick(pecas[pos_random], jogo[0].left, jogo[jogo.length-1].right)!=-1) { // quando puder jogar uma peça
				i = pos_random;
				oponente.push(pecas[pos_random]);
				pecas.splice(pos_random,1);
				break;
			}
			else { // enquanto não consegue jogar nenhuma peça
				oponente.push(pecas[pos_random]);
				// por pecas na div
				var contas = 50+127025+pecas[pos_random].left*7+pecas[pos_random].right;
				var elem = document.createElement("span");
				elem.setAttribute("id","peca("+oponente[oponente.length-1].left +""+ oponente[oponente.length-1].right +")");
				elem.innerHTML = "&#" + contas;
				document.getElementById("jogo_oponente").appendChild(elem);
				pecas.splice(pos_random, 1);
			}
		}
	}
	var childPos = children[i];
	var jogada = verifyClick(oponente[i],jogo[0].left,jogo[jogo.length-1].right);
	if(jogada == -1)return;
	if(jogada == 2 || jogada == 4){
		var contas;
		if(oponente[i].right === oponente[i].left)
			contas = 127025+oponente[i].left*7+oponente[i].right+50;
		else
			contas = 127025+oponente[i].right*7+oponente[i].left;
		var elem = document.createElement("span");
		elem.innerHTML = "&#" + contas;
		if(jogada == 2){
			jogo.unshift(new Peca(oponente[i].right,oponente[i].left));
			document.getElementById("jogo").insertBefore(elem,document.getElementById("jogo").childNodes[0]);
			document.getElementById("jogo_oponente").removeChild(childPos);
			oponente.splice(i,1);
		}
		else if(jogada == 4) {
			jogo.push(new Peca(oponente[i].right,oponente[i].left));
			document.getElementById("jogo").appendChild(elem);
			document.getElementById("jogo_oponente").removeChild(childPos);
			oponente.splice(i,1);
		}
	}
	else if(jogada == 3){
		var contas;
		if(oponente[i].right === oponente[i].left)
			contas = 127025+oponente[i].left*7+oponente[i].right+50;
		else
			contas = 127025+oponente[i].left*7+oponente[i].right;
		var elem = document.createElement("span");
		elem.innerHTML = "&#" + contas;
		jogo.unshift(oponente[i]);
		document.getElementById("jogo").insertBefore(elem,document.getElementById("jogo").childNodes[0]);
		document.getElementById("jogo_oponente").removeChild(childPos);
		oponente.splice(i,1);
	}
	else if(jogada == 1){
		var contas;
		if(oponente[i].right === oponente[i].left)
			contas = 127025+oponente[i].left*7+oponente[i].right+50;
		else
			contas = 127025+oponente[i].left*7+oponente[i].right;
		var elem = document.createElement("span");
		elem.innerHTML = "&#" + contas;
		jogo.push(oponente[i]);
		document.getElementById("jogo").appendChild(elem);
		document.getElementById("jogo_oponente").removeChild(childPos);
		oponente.splice(i,1);
	}
	aparecer_passar();
	isWinner();
	flag = 1;
}

function verifyClick(peca,l,r){ //peca|tab : 1->esq|dir ; 2->esq|esq; 3->dir|esq; 4->dir|dir
	console.log(peca);
	if(peca.left === r) return 1;
	if(peca.left === l) return 2;
	if(peca.right === l) return 3;
	if(peca.right === r) return 4;

	return -1;
}

// Utilizador ir buscar ao monte
function irMonte() {
	if(pecas.length == 0) return;
	var i;
	for(i = 0; i < user.length; i++) {
		if(verifyClick(user[i], jogo[0].left, jogo[jogo.length-1].right) != -1) {
			window.alert("Olhe com mais atenção para o seu jogo");
			return;
		}
	}
	console.log("Monte");
	while(pecas.length > 0){ // ir buscar monte
		var childs = document.getElementById("monte").childNodes;
		var child = childs[0];
		child.innerHTML = "";
		child.innerHTML = "&#127074;" + pecas.length;
		var idp;
		var pos_random = Math.floor(Math.random()*pecas.length);
		if(verifyClick(pecas[pos_random], jogo[0].left, jogo[jogo.length-1].right)!=-1) { // quando puder jogar uma peça
			user.push(pecas[pos_random]);
			idp = "" + pecas[pos_random].left + "" + pecas[pos_random].right + "";
			var contas = 50+127025+pecas[pos_random].left*7+pecas[pos_random].right;
			var elem = document.createElement("span");
			elem.setAttribute("id","peca("+user[user.length-1].left +""+ user[user.length-1].right +")");
			elem.setAttribute("onclick", "jogar("+idp+")");
			elem.innerHTML = "&#" + contas;
			document.getElementById("jogo_utilizador").appendChild(elem);
			pecas.splice(pos_random,1);
			break;
		}
		else { // enquanto não consegue jogar nenhuma peça
			user.push(pecas[pos_random]);
			idp = "" + pecas[pos_random].left + "" + pecas[pos_random].right + "";
			var contas = 50+127025+pecas[pos_random].left*7+pecas[pos_random].right;
			var elem = document.createElement("span");
			elem.setAttribute("id","peca("+user[user.length-1].left +""+ user[user.length-1].right +")");
			elem.setAttribute("onclick", "jogar("+idp+")");
			elem.innerHTML = "&#" + contas;
			document.getElementById("jogo_utilizador").appendChild(elem);
			pecas.splice(pos_random,1);
		}
	}
	var childs = document.getElementById("monte").childNodes;
		var child = childs[0];
		child.innerHTML = "";
		child.innerHTML = "&#127074;" + pecas.length;
}

function isWinner() {
	var nomeuser = document.getElementById("user_cmpc");		
	if(user.length == 0) {
		window.alert("Venceu " + user_cmpc.value + "!");
		return;
	}
	else if(oponente.length == 0) {
		window.alert("Venceu PC!");
		return;
	}
	if(pecas.length == 0) {
		var n_user = 0;
		for(var i = 0; i < user.length; i++) {
			if(verifyClick(user[i], jogo[0].left, jogo[jogo.length-1].right) != -1)
				n_user = 1;
		}
		var n_oponente = 0;
		for(var i = 0; i < oponente.length; i++) {
			if(verifyClick(oponente[i], jogo[0].left, jogo[jogo.length-1].right) != -1)
				n_oponente = 1;
		}
		var soma_user = 0;
		for(var i = 0; i < user.length; i++)
			soma_user += user[i].length + user[i].right;
		var soma_oponente = 0;
		for(var i = 0; i < oponente.length; i++)
			soma_oponente += oponente[i].length + oponente[i].right;
		if(n_user == 0 && n_oponente == 0) {
			if(soma_user < soma_oponente) {
				window.alert("Venceu " + user_cmpc.value + "!");
				return;
			}
			else if(soma_user > soma_oponente) {
				window.alert("Venceu PC!");
				return;
			}
			else if(soma_user == soma_oponente) {
				window.alert("Empate!");
				return;
			}
		}
	}
	else return;
}

function giveUp() {
	window.alert("Desistiu do jogo");
	gameStart();
}

function aparecer_passar() {
	if(pecas.length == 0) {
		document.getElementById("passar").style.display = 'block';
		document.getElementById("monte_pc").style.display = 'none';
	}
}

