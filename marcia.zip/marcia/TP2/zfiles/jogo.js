// Dominó - Trabalho Prático 2 TW

/* Aparece a área de login numa janela sobreposta à página quando carregamos no botão online */
var modal_on = document.getElementById("show_online");

// Quando o utilizador carrega no botão, abre a janela 
document.getElementById("online").addEventListener("click", btnon);
function btnon() {
	modal_on.style.display = "block";
};
// Quando o utilizador carrega no <span> x, fecha a janela
document.getElementsByClassName("close_on")[0].addEventListener("click", function span0(){
	spanon();
});
function spanon() {
	modal_on.style.display = "none";
}

// Aparece as opções quando carregar no botão offline
document.getElementById("offline").addEventListener("click", function formoff(){
	showChooseForm();
});
function showChooseForm() {
	if(document.getElementById('op_offline').style.display == 'block')
		document.getElementById('op_offline').style.display = 'none';
	else
		document.getElementById('op_offline').style.display = 'block';
}

var paginainicial = document.getElementById('pagina_inicial');

// Jogar contra o computador
document.getElementById("offline_vspc").addEventListener("click", function formoffop(){
	tab1();
});
function tab1() {
	document.body.style.backgroundImage = "url(zfiles/imagens/fundo2.png)";
	paginainicial.style.display = 'none';
	document.getElementById('offline_pc').style.display = 'block';
	document.getElementById("easy").disabled = true;
	document.getElementById("medium").disabled = true;
	document.getElementById("hard").disabled = true;
}

/* Aparece as regras quando carregar no botão regras na página principal*/
document.getElementById("regras").addEventListener("click", function showregrasmenu(){
	regras();
});
function regras() {
	if(document.getElementById('op_regras').style.display == 'block')
		document.getElementById('op_regras').style.display = 'none';
	else
		document.getElementById('op_regras').style.display = 'block';
}

/* Aparece as regras quando carregar no botão regras na área de jogo*/
var modal = document.getElementById("mymodal");
// Quando o utilizador carrega no botão, abre a janela 
document.getElementById("show_regras").addEventListener("click", btnregras);
function btnregras() {
	modal.style.display = "block";
}
// Quando o utilizador carrega no <span> x, fecha a janela
document.getElementsByClassName("closeregras")[0].addEventListener("click", function span_regras(){
	spanregras();
});
function spanregras() {
	modal.style.display = "none";
}
// Quando o utilizador carrega em qualquer sitio sem ser na janela, fecha a janela
window.onclick = function(event) {
	if (event.target == modal) {
		modal.style.display = "none";
	}
}

function nome_user_pont(){
	var submit = document.getElementById("submit_user");
	var nomeuser = document.getElementById("user_cmpc");
	if(nomeuser.value == ""){
		window.alert("Utilizador inexistente!");
	}
	else{
		document.getElementById("utilizador_temp").style.display = "none";
		document.getElementById("nome_user").style.display = "block";
		document.getElementById("nome_user").innerHTML = "Pontuação " + nomeuser.value + ":";
		document.getElementById("user_cmpc").style.display = "none";
		document.getElementById("userText").style.display = "none";
		submit.style.display = "none";
		document.getElementById("easy").disabled = false;
		document.getElementById("medium").disabled = false;
		document.getElementById("hard").disabled = false;
	}
}

function show_mesa() {
	if(document.getElementById("submit_user").style.display == "none") {
		document.getElementById("easy").disabled = true;
		document.getElementById("medium").disabled = true;
		document.getElementById("hard").disabled = true;
		document.getElementById("mesa_pc").style.display = "block";
		document.getElementById("monte_pc").style.display = "block";
		document.getElementById("desistir").style.display = "block";
	}
	else {
		window.alert("Submissão inexistente!");
	}
}

// **********************************************************************************************

document.getElementById("loginPlayer").addEventListener("click",function logp(){
	logReg();
});

//SERVER CONNECTION
var link = "http://twserver.alunos.dcc.fc.up.pt:8008/";
var nameGlobal = "";
var passGlobal = "";
var groupGlobal = "groupMM";
var gameIdGlobal = "";

// REGISTER
function logReg(){
	score();
	var name = document.getElementById("user").value;
	var pass = document.getElementById("pass").value;

	nameGlobal = name;
	passGlobal = pass;
	conta = {
		nick : name,
		pass : pass
	}
	fetch(link + "register",{
		method : "POST",
		body : JSON.stringify(conta)
	})
	.then(function (resposta){
		return resposta.text();
	})
	.then(function (texto){
		if(texto != "{}") {
			console.log(texto);
			window.alert("Registo falhado por erro na password");
		}
		else if(name === "" || pass === "")
			window.alert("Preencha os campos");
		else {
			console.log(texto);
			pageON();
		}
	});
}

// JOIN
function pageON() {
	info_jogo = {
		group : groupGlobal,
		nick : nameGlobal,
		pass : passGlobal
	}
	fetch(link + "join", {
		method : "POST",
		body : JSON.stringify(info_jogo)
	})
	.then(function (resposta){
		return resposta.json();
	})
	.then(function (texto){
		gameIdGlobal = texto.game;
		console.log(texto);
		show_pageON();
	});
}

var paginainicial2 = document.getElementById('pagina_inicial');

function show_pageON() {
	document.body.style.backgroundImage = "url(zfiles/imagens/fundo2.png)";
	paginainicial2.style.display = 'none';
	document.getElementById('online_jogo').style.display = 'block';
}

document.getElementById("start_game").addEventListener("click", show_mesaON);

function show_mesaON() {
	document.getElementById("start_game").style.display = "none";
	document.getElementById("mesaON").style.display = "block";
	document.getElementById("monte_ONLINE").style.display = "block";
	document.getElementById("desistirON").style.display = "block";
}

/* Aparece as regras quando carregar no botão regras na área de jogo do ONLINE*/
var modal_regrasOn = document.getElementById("mymodalON");
// Quando o utilizador carrega no botão, abre a janela 
document.getElementById("show_regrasON").addEventListener("click", btnregrasOn);
function btnregrasOn() {
	modal_regrasOn.style.display = "block";
}
// Quando o utilizador carrega no <span> x, fecha a janela
document.getElementsByClassName("closeregrason")[0].addEventListener("click", function span_regrasOn(){
	spanregrason();
});
function spanregrason() {
	modal_regrasOn.style.display = "none";
}
// Quando o utilizador carrega em qualquer sitio sem ser na janela, fecha a janela
window.onclick = function(event) {
	if (event.target == modal) {
		modal.style.display = "none";
	}
}

// LEAVE
function sair() {
	desistir = {
		nick : nameGlobal,
		pass : passGlobal,
		game : gameIdGlobal
	}
	fetch(link + "leave", {
		method : "POST",
		body : JSON.stringify(desistir)
	})
	.then(function (resposta){
		return resposta.text();
	})
	.then(function (texto){
		console.log(texto);
		console.log("logout");
	});
}

document.getElementById("desistirON").addEventListener("click", sair);

// RANKING
function score() {
	fetch(link + "ranking", {
		method : "POST",
		body : JSON.stringify("")
	})
	.then(function (resposta){
		return resposta.json();
	})
	.then(function (texto){
		printRanks(texto.ranking);
	});
}

var modal_pontON = document.getElementById("table_pont");
// Quando o utilizador carrega no botão, abre a janela 
document.getElementById("pontuacaoON").addEventListener("click", btnpontON);
function btnpontON() {
	modal_pontON.style.display = "block";
}
// Quando o utilizador carrega no <span> x, fecha a janela
document.getElementsByClassName("close_pontON")[0].addEventListener("click", function spanpontON(){
	span_pontON();
});
function span_pontON() {
	modal_pontON.style.display = "none";
}

function printRanks(arr){
	var tab = document.getElementById("tab_raking");

	while(tab.firstChild){
		tab.removeChild(tab.firstChild);
	}
	var trM = document.createElement("tr");
	var th1 = document.createElement("th");
	var th2 = document.createElement("th");
	var th3 = document.createElement("th");
	th1.innerHTML = "Nome utilizador";
	th2.innerHTML = "Vitorias";
	th3.innerHTML = "Jogos";
	trM.appendChild(th1);
	trM.appendChild(th2);
	trM.appendChild(th3);
	tab.appendChild(trM);

	for(var i =0 ; i<arr.length; i++){
		var trI = document.createElement("tr");
		var thI1 = document.createElement("th");
		var thI2 = document.createElement("th");
		var thI3 = document.createElement("th");
		thI1.innerHTML = arr[i].nick;
		thI2.innerHTML = arr[i].victories;
		thI3.innerHTML = arr[i].games;
		trI.appendChild(thI1);
		trI.appendChild(thI2);
		trI.appendChild(thI3);
		tab.appendChild(trI);
	}
}

//--------------------

//PLAYER VS PLAYER ALGORITHM

function start() {

}

//--------------------
