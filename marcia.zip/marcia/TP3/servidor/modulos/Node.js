const http = require('http');
const url = require('url');

const server = http.createServer(function (request, response) {
	const parsedUrl = url.parse(request.url,true);
	const query = parsedUrl.query;
	const name = query.name == undefined? 'amig@': query.name;
	const mensagem = 'Podes repetir?';
	const pathname = parsedUrl.pathname;

	switch(pathname) { //Aqui o stor tem (parsedURL.pathname)
		case '/hello':
		mensagem = 'Olá '+name;
		break;
		case '/bye':
		mensagem = 'Adeus '+name;
		break;
	}
	switch(request.method) {
		let body = '';
		case 'POST':
		request
			.on('data', (chunk) => { body += chunk; })
			.on('end', () => {
				try { query = JSON.parse(body); /* processar query */ }
				catch(err) { /* erros de JSON */ }
			})
			.on('error', (err) => { console.log(err.message); });
		break;
	}
	const query = parsedUrl.query;
	const fs = require('fs');
	fs.readFile('dados.txt', 'utf8', function(err,data) {
		if(! err) {
			dados = JSON.parse(data.toString());
			// processar data como string
		}
	});
	fs.writeFile("dados.txt", dados_string,(err) => {
		if(err) throw err;
	});
	fs.writeFile('dados.txt',JSON.stringify(dados),function(err) {
		if(! err) {
			// continuar;
		}
	});
	var dados = fs.readFileSync('dados.txt');
	fs.writeFileSync('dados.txt',dados);
	fs.stat(pathname, (err,stats) => {
		if(err) throw err;
		console.log(pathname+' tem '+stats.size+' bytes');
	});
	const conf = require('./conf.js');
	// ...
	// *******************************
	//  module.exports.documentRoot = '/ '; 
	module.exports.defaultIndex = 'index.html';
	module.exports.port = 8142;
	module.exports.mediaTypes = {
	    'txt':      'text/plain',
	    'html':     'text/html',
	    'css':      'text/css',
	    'js':       'application/javascript',
	    'png':      'image/png',
	    'jpeg':     'image/jpeg',
	    'jpg':      'image/jpeg',
	}

	http.createServer((request,response) => {
	    switch(request.method) {
	    case 'GET':
	        doGetRequest(request,response);
	        break;
	    default:
	        response.writeHead(501); // 501 Not Implemented
	        response.end();    
	    }
	}).listen(conf.port);

	function doGetRequest(request,response) {
	    const pathname = getPathname(request);
	    if(pathname === null) {
	        response.writeHead(403); // Forbidden
	        response.end();
	    } else 
	        fs.stat(pathname,(err,stats) => {
	            if(err) {
	                response.writeHead(500); // Internal Server Error
	                response.end();
	            } else if(stats.isDirectory()) {
	                if(pathname.endsWith('/'))
	                   doGetPathname(pathname+conf.defaultIndex,response);
	                else {
	                   response.writeHead(301, // Moved Permanently
	                                      {'Location': pathname+'/' });
	                   response.end();
	                }
	            } else 
	                doGetPathname(pathname,response);
	       });    
	}

	function getPathname(request) {
	    const purl = url.parse(request.url);
	    let pathname = path.normalize(conf.documentRoot+purl.pathname);
	    if(!pathname.startsWith(conf.documentRoot))
	       pathname = null;
	    return pathname;
	}	

	function doGetPathname(pathname,response) {
	    const mediaType = getMediaType(pathname);
	    const encoding = isText(mediaType) ? "utf8" : null;

	    fs.readFile(pathname,encoding,(err,data) => {
	    if(err) {
	        response.writeHead(404); // Not Found
	        response.end();
	    } else {
	        response.writeHead(200, { 'Content-Type': mediaType });
	        response.end(data);
	    }
	  });    
	}

	function getMediaType(pathname) {
	    const pos = pathname.lastIndexOf('.');
	    let mediaType;
	    if(pos !== -1) 
	       mediaType = conf.mediaTypes[pathname.substring(pos+1)];
	    if(mediaType === undefined)
	       mediaType = 'text/plain';
	    return mediaType;
	}
	function isText(mediaType) {
	    if(mediaType.startsWith('image'))
	      return false;
	    else
	      return true;
	}
	// *******************************
	// ...
	response.writeHead(200, {'Content-Type': 'text/plain'});
	response.write('Método: '+request.method+'\n');
	response.write('URL: '+request.url+'\n');
	response.end();
});

server.listen(8142);