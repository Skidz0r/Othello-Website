"use strict";

const crypto = require('crypto');
const fs = require('fs');
const headers = require('./headers.js');

let ref = [];

module.exports.get = function() {
	// ...
}

module.exports.register = function(nick, pass, response) {
	console.log(nick + " " + pass);
	if(nick === undefined || nick === null) {
		response.writeHead(400, headers['plain']); // 400 Erro no pedido
		response.write(JSON.stringify({error : "Nome do utilizador inexistente!"}));
		response.end();
		return;
		//break;
	}
	else if(pass === undefined || pass === null) {
		response.writeHead(400, headers['plain']); // 400 Erro no pedido
		response.write(JSON.stringify({error : "Password inexistente!"}));
		response.end();
		return;
		//break;
	}
	else if(nick == "") {
		response.writeHead(401, headers['plain']); // 401 Pedido não autorizado
		response.write(JSON.stringify({error : "Nome do utilizador inválido!"}));
		response.end();
		return;
		//break;
	}
	else if(pass == "") {
		response.writeHead(401, headers['plain']); // 401 Pedido não autorizado
		response.write(JSON.stringify({error : "Password inválido!"}));
		response.end();
		return;
		//break;
	}
	else{
		console.log("Registo com Sucesso");
		response.writeHead(200, headers["plain"]);
		response.write(JSON.stringify({}));
		response.end();
	}

	const path = './info.json';
	let infoData;
	const hash = crypto.createHash('md5').update(pass).digest('hex'); // encriptar a password

	try {
		if(fs.existsSync(path)) { // Se o ficheiro com as contas dos utilizadores existir
			fs.readFile(path, function(err, data) {
				if(err) 
					throw err;
				infoData = JSON.parse(data);
			});
			if(infoData[nick] !== undefined || infoData[nick] !== null) {
				if(infoData[nick].pass !== hash) {
					response.writeHead(401, headers['plain']); // 401 Pedido não autorizado
					response.write(JSON.stringify({error : "Password inválido!"}));
					response.end();
					return;
					//break;
				}
				else {
					response.writeHead(200, headers['plain']); // 200 Pedidos bem sucedidos
					response.write(JSON.stringify({}));
					response.end();
					return;
					//break;
				}
			}
			else {
				infoData[nick].pass = hash;
				infoData[nick].games = 0;
				infoData[nick].victories = 0;
			}

			console.log(infoData);

			fs.writeFile(path, infoData, function(err) {
				if(err)
					console.log(err);
				else console.log("O ficheiro está guardado!");
			});
		}
		else { // Se  não existir nenhum ficheiro, ou seja, se não existir nenhuma conta
			infoData[nick].pass = hash;
			infoData[nick].games = 0;
			infoData[nick].victories = 0;
			response.writeHead(200, headers['plain']); // 200 Pedidos bem sucedidos
			response.write(JSON.stringify({}));
			response.end();

			console.log(infoData);

			fs.writeFile(path, infoData, function(err) {
				if(err)
					console.log(err);
				else console.log("O ficheiro está guardado!");
			});
		}
	} catch (err) {
		console.error("error: " + err);
	}
}

module.exports.ranking = function(response) {
	const path = './info.json';
	let infoData;

	try {
		if(fs.existsSync(path)) { // Se o ficheiro com as contas dos utilizadores existir
			fs.readFile(path, function(err, data) {
				if(err) 
					throw err;
				infoData = JSON.parse(data);
			});
		}
		else { // Se  não existir nenhum ficheiro, ou seja, se não existir nenhuma conta
			response.writeHead(200, headers[200]); // 200 Pedido bem sucedido
			response.write(JSON.stringify({ranks : []}));
			response.end();
			break;
		}
	} catch (err) {
		console.error(err);
	}
	let rankings = [];
	for(let i in infoData) {
		rankings.push({
			nick: i,
			victories: infoData[i].victories,
			games: infoData[i].games
		});
	}
	response.writeHead(200, headers['plain']); // 200 Pedido bem sucedido
	response.write(JSON.stringify({ranks : rankings}));
	response.end();
}

module.exports.join = function(nick, pass, game, response) {
	if(nick === null) {
		response.writeHead(400, headers['plain']); // 400 Erro no pedido
		response.write(JSON.stringify({error : "Nome do utilizador inexistente!"}));
		response.end();
		break;
	}
	else if(pass === null) {
		response.writeHead(400, headers['plain']); // 400 Erro no pedido
		response.write(JSON.stringify({error : "Password inexistente!"}));
		response.end();
		break;
	}
	else if(nick == "") {
		response.writeHead(401, headers['plain']); // 401 Pedido não autorizado
		response.write(JSON.stringify({error : "Nome do utilizador inválido!"}));
		response.end();
		break;
	}
	else if(pass == "") {
		response.writeHead(401, headers['plain']); // 401 Pedido não autorizado
		response.write(JSON.stringify({error : "Password inválida!"}));
		response.end();
		break;
	}
	else if(game === null) {
		response.writeHead(401, headers['plain']); // 401 Pedido não autorizado
		response.write(JSON.stringify({error : "Jogo inexistente!"}));
		response.end();
		break;
	}
	else if(game == "") {
		response.writeHead(401, headers['plain']); // 401 Pedido não autorizado
		response.write(JSON.stringify({error : "Jogo inválido!"}));
		response.end();
		break;
	}

	const path = './info.json';
	let infoData;
	const hash = crypto.createHash('md5').update(pass).digest('hex'); // encriptar a password

	try {
		if(fs.existsSync(path)) { // Se o ficheiro com as contas dos utilizadores existir
			fs.readFile(path, function(err, data) {
				if(err) 
					throw err;
				infoData = JSON.parse(data);
			});
			if(infoData[nick] !== null) {
				if(infoData[nick].pass !== hash) {
					response.writeHead(401, headers['plain']); // 401 Pedido não autorizado
					response.write(JSON.stringify({error : "Password inválida!"}));
					response.end();
					break;
				}
				else {
					response.writeHead(200, headers['plain']); // 200 Pedidos bem sucedidos
					response.write(JSON.stringify({}));
					response.end();
					break;
				}
			}
			else {
				response.writeHead(400, headers['plain']); // 400 Pedido não autorizado
				response.write(JSON.stringify({error : "Jogador inexistente!"}));
				response.end();
				break;
			}
		}
		else { // Se  não existir nenhum ficheiro, ou seja, se não existir nenhuma conta
			response.writeHead(400, headers['plain']); // 400 Pedido não autorizado
			response.write(JSON.stringify({error : "Jogador inexistente!"}));
			response.end();
			break;
		}
	} catch (err) {
		console.error(err);
	}

	const gameID = crypto.randomBytes(20).toString('hex'); // criar uma string para o ID do jogo

	for(let i = 0; i < ref.length; i++) {
		if(ref[i].id == gameID){
			response.writeHead(200, headers['plain']); // 200 Pedido bem sucedido
			response.write(JSON.stringify({game : gameID}));
			response.end();
			return;
		}
	}

	ref.push({
		game : gameID,
		players : 1,
		turn : 1,
		board : []
		// ... 
	});
	//crias sala
	//respondes o id da sala 200
	response.writeHead(200, headers['plain']); // 200 Pedido bem sucedido
	response.write(JSON.stringify({game: gameID}));
	response.end();
	return;
}

module.exports.leave = function(nick, pass, game, response) {
	if(nick === null) {
		response.writeHead(400, headers['plain']); // 400 Erro no pedido
		response.write(JSON.stringify({error : "Nome do utilizador inexistente!"}));
		response.end();
		break;
	}
	else if(pass === null) {
		response.writeHead(400, headers['plain']); // 400 Erro no pedido
		response.write(JSON.stringify({error : "Password inexistente!"}));
		response.end();
		break;
	}
	else if(nick == "") {
		response.writeHead(401, headers['plain']); // 401 Pedido não autorizado
		response.write(JSON.stringify({error : "Nome do utilizador inválido!"}));
		response.end();
		break;
	}
	else if(pass == "") {
		response.writeHead(401, headers['plain']); // 401 Pedido não autorizado
		response.write(JSON.stringify({error : "Password inválida!"}));
		response.end();
		break;
	}
	else if(game === null) {
		response.writeHead(401, headers['plain']); // 401 Pedido não autorizado
		response.write(JSON.stringify({error : "Jogo inexistente!"}));
		response.end();
		break;
	}
	else if(game == "") {
		response.writeHead(401, headers['plain']); // 401 Pedido não autorizado
		response.write(JSON.stringify({error : "Jogo inválido!"}));
		response.end();
		break;
	}

	const path = './info.json';
	let infoData;
	const hash = crypto.createHash('md5').update(pass).digest('hex'); // encriptar a password

	try {
		if(fs.existsSync(path)) { // Se o ficheiro com as contas dos utilizadores existir
			fs.readFile(path, function(err, data) {
				if(err) 
					throw err;
				infoData = JSON.parse(data);
			});
				if(infoData[nick].pass !== hash) {
					response.writeHead(401, headers['plain']); // 401 Pedido não autorizado
					response.write(JSON.stringify({error : "Password inválida!"}));
					response.end();
					break;
				}
				else {
					response.writeHead(200, headers['plain']); // 200 Pedidos bem sucedidos
					response.write(JSON.stringify({}));
					response.end();
					break;
				}
			}
			else {
				response.writeHead(400, headers['plain']); // 400 Pedido não autorizado
				response.write(JSON.stringify({error : "Jogador inexistente!"}));
				response.end();
				break;
			}
	} catch (err) {
		console.error(err);
	}

	for(let i=0; i < ref.length; i++) {
		if(game === ref[i].game) {
			//if(sala em jogo) {
				//dar vitoria ao outro jogador;
				//atualiza ranks;
				//remove sala; ref.splice(i,1);
			//}
			//else {
				//remove sala; ref.splice(i,1);
			//}
		}
	}
}

module.exports.notify = function(nick, pass, game, side, piece, skip, response) {
	// ...
}