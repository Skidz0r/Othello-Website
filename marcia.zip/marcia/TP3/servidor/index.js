/*
"use strict";

const http = require('http');
const url = require('url');
const headers = require('./modulos/headers.js');
const req = require('./modulos/aboutRequests.js');

http.createServer(function(request, response) { 
	switch(request.method) {
		case "GET":
			req.doGetRequest(request, response);
			break;
		case "POST":
			req.doPostRequest(request, response);
			break;
		default:
			response.writeHead(404, headers['plain']); // 404 Pedido desconhecido
			response.end();
			break;
	}
}).listen(8142);
*/

"use strict";

const http = require('http');
const url = require('url');
const headers = require('./modulos/headers.js');
const req = require('./modulos/aboutRequests.js');

const hostname = '127.0.0.1';
const port = 8142;

const server = http.createServer(function(request, response) { 
	request.method = "POST";
	console.log(request.method);
	switch(request.method) {
		case "GET":
			console.log("get");
			req.doGetRequest(request, response);
			break;
		case "POST":
			console.log("post");
			req.doPostRequest(request, response);
			break;
		default:
			console.log("default");
			response.writeHead(404, headers['plain']); // 404 Pedido desconhecido
			response.end();
			break;
	}
}); //.listen(8142);

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
/**/