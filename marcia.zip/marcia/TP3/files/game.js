/* Dominó - Trabalho Prático 2 TW */

// Início da janela de Login para jogar ONLINE
var modalON = document.getElementById('show_online');

document.getElementById('online').addEventListener('click', function() {
	modalON.style.display = 'block';
});

document.getElementById('close_on').addEventListener('click', function() {
	modalON.style.display = 'none';
});
// Fim da janela de Login para jogar ONLINE

// Carregar na opção OFFLINE para escolher entre jogar contra pc ou um Amigo
document.getElementById('offline').addEventListener('click', function() {
	var opOFF = document.getElementById('op_offline');
	if(opOFF.style.display == 'block')
		opOFF.style.display = 'none';
	else
		opOFF.style.display = 'block';
	document.getElementById('offline_vsamigo').disabled = true;
});

var pageINICIAL = document.getElementById('pagina_inicial');

// Início do jogo contra o PC 
document.getElementById('offline_vspc').addEventListener('click', function() {
	document.body.style.backgroundImage = 'url(files/imagens/fundo2.png)';
	pageINICIAL.style.display = 'none';
	document.getElementById('offline_pc').style.display = 'block';
	document.getElementById('easy').disabled = true;
	document.getElementById('medium').disabled = true;
	document.getElementById('hard').disabled = true;
});

// Início da Janela das regras do jogo (OFFLINE - CONTRA PC)
var modalREGRAS = document.getElementById('mymodal');

document.getElementById('show_regras').addEventListener('click', function() {
	modalREGRAS.style.display = 'block';
});

document.getElementById('closeregras').addEventListener('click', function() {
	modalREGRAS.style.display = 'none';
});

window.onclick = function(event) {
	if(event.target == modalREGRAS)
		modalREGRAS.style.display = 'none';
}

// Fim da Janela das regras do jogo (OFFLINE - CONTRA PC)

function nome_user_pont() {
	var nomeuser = document.getElementById('user_cmpc');
	if(nomeuser.value == "")
		window.alert("Utilizador inexistente!");
	else {
		document.getElementById('utilizador_temp').style.display = 'none';
		document.getElementById('nome_user').style.display = 'block';
		document.getElementById('nome_user').innerHTML = "Pontução " + nomeuser.value + ":";
		document.getElementById('user_cmpc').style.display = 'none';
		document.getElementById('userText').style.display = 'none';
		document.getElementById('submit_user').style.display = 'none';
		document.getElementById('easy').disabled = false;
		document.getElementById('medium').disabled = false;
		document.getElementById('hard').disabled = false;
	}
}

function show_mesa() {
	if(document.getElementById('submit_user').style.display == 'none') {
		document.getElementById('easy').disabled = true;
		document.getElementById('medium').disabled = true;
		document.getElementById('hard').disabled = true;
		document.getElementById('mesa_pc').style.display = 'block';
		document.getElementById('monte_pc').style.display = 'block';
		document.getElementById('desistir').style.display = 'block';
	}
	else
		window.alert("Submissão inexistente!");
}
// Fim do jogo contra o PC 

// Regras na página inicial
document.getElementById('regras').addEventListener('click', function() {
	var opREGRAS = document.getElementById('op_regras');
	if(opREGRAS.style.display == 'block')
		opREGRAS.style.display = 'none';
	else
		opREGRAS.style.display = 'block';
});

// Início do jogo ONLINE
document.getElementById('loginPlayer').addEventListener('click', register);

// SERVER CONNECTION
//var link = "http://twserver.alunos.dcc.fc.up.pt:8142"; // VERIFICAR
var link = "http://localhost:8142/";
var nameGlobal = "";
var passGlobal = "";
var groupGlobal = "";
var gameGlobal = "";
var playerHand = [];
var piecesOponente;

// REGISTER
function register() {
	//ranking(); // ranking inicial

	nameGlobal = document.getElementById('user').value;
	passGlobal = document.getElementById('pass').value;

	conta = {
		nick : nameGlobal,
		pass : passGlobal
	}
	console.log(conta);
	fetch(link + "register", {
		method : "POST",
		body : JSON.stringify(conta)
	})
	.then(function(resposta) {
		return resposta.text();
	})
	.then(function(texto) {
		if(texto != "{}")
			window.alert("Registo falhado por erro na password!");
		else if(nameGlobal === "" || passGlobal === "")
			window.alert("Preencha os campos");
		else {
			document.body.style.backgroundImage = "url(files/imagens/fundo2.png)";
			pageINICIAL.style.display = 'none';
			document.getElementById('online_jogo').style.display = 'block';
		}
	});
}

// JOIN
function join() {
	conta_group = {
		group : groupGlobal,
		nick : nameGlobal,
		pass : passGlobal
	}
	fetch(link + "join", {
		method : "POST",
		body : JSON.stringify(conta_group)
	})
	.then(function(resposta) {
		return resposta.json();
	})
	.then(function(texto) {
		gameGlobal = texto.game;
		if(texto.hand == null) {
			// leave(); // sair do jogo por falta de peças
			join();
			return;
		}
		// receber a mão do jogador
		for(var i = 0; i < texto.hand.legth; i++)
			playerHand[i] = new Peca(texto.hand[i][0], texto.hand[i][1]);
		// aparecer a mesa de jogo
		document.getElementById('start_game').style.display = 'none';
		document.getElementById('mesaON').style.display = 'block';
		document.getElementById('monte_ONLINE').style.display = 'block';
		document.getElementById('desistirON').style.display = 'block';
		// printMount(); // imprimir o número de peças no monte
		// print_mesa(); // imprimir a mesa de jogo(mão do jogador e do oponente, e o jogo no centro)
		// start() ... // iniciar o jogo	
	});
}
// Começar o jogo (join + update)
document.getElementById('start_game').addEventListener('click', function() {
	join();
	update();
});

// Início da Janela das regras do jogo (ONLINE)
var modalREGRASon = document.getElementById('mymodalON');

document.getElementById('show_regrasON').addEventListener('click', function() {
	modalREGRASon.style.display = 'block';
});

document.getElementById('closeregrason').addEventListener('click', function() {
	modalREGRASon.style.display = 'none';
});

window.onclick = function(event) {
	if(event.target == modalREGRASon)
		modalREGRASon.style.display = 'none';
}
// Fim da Janela das regras do jogo (ONLINE)

// NOTIFY
function notify_pedir() {
	conta_pedir = {
		nick : nameGlobal,
		pass : passGlobal,
		game : gameGlobal,
		piece : null
	}
	fetch(link + 'notify', {
		method : 'POST',
		body : JSON.stringify(conta_pedir)
	})
	.then(function(resposta) {
		return resposta.json();
	})
	.then(function(texto) {
		window.alert("Peça recebida: " + texto.piece);
	})
}

function notify_jogar(piece, side) {
	conta_jogar = {
		nick : nameGlobal,
		pass : passGlobal,
		game : gameGlobal,
		piece : piece,
		side : side
	}
	fetch(link + 'notify', {
		method : 'POST',
		body : JSON.stringify(conta_jogar)
	})
	.then(function(resposta) {
		return resposta.json();
	})
	.then(function(texto) {
		window.alert("Jogou a peça: " + texto.piece);
	});
}

function notify_passar() {
	conta_passar = {
		nick : nameGlobal,
		pass : passGlobal,
		game : gameGlobal,
		skip : null
	}
	fetch(link + 'notify', {
		method : 'POST',
		body : JSON.stringify(conta_passar)
	})
	.then(function(resposta) {
		return resposta.json();
	})
	.then(function(texto) {
		window.alert("Passou a vez! ("+ texto + ")");
	});
}

// UPDATE
// ...

// LEAVE
// ...

// RANKING
// ...

// PLAYER VS PLAYER (ALGORITHM)
// ...
// Fim do jogo ONLINE