// Dominó - Trabalho Prático 2 TW

/* Aparece a área de login numa janela sobreposta à página quando carregamos no botão online */
var modal_on = document.getElementById("show_online");

// Quando o utilizador carrega no botão, abre a janela 
document.getElementById("online").addEventListener("click", btnon);
function btnon() {
	modal_on.style.display = "block";
};
// Quando o utilizador carrega no <span> x, fecha a janela
document.getElementsByClassName("close_on")[0].addEventListener("click", function span0(){
	spanon();
});
function spanon() {
	modal_on.style.display = "none";
}

// Aparece as opções quando carregar no botão offline
document.getElementById("offline").addEventListener("click", function formoff(){
	showChooseForm();
});
function showChooseForm() {
	if(document.getElementById('op_offline').style.display == 'block')
		document.getElementById('op_offline').style.display = 'none';
	else
		document.getElementById('op_offline').style.display = 'block';
}

var paginainicial = document.getElementById('pagina_inicial');

// Jogar contra o computador
document.getElementById("offline_vspc").addEventListener("click", function formoffop(){
	tab1();
});
function tab1() {
	document.body.style.backgroundImage = "url(files/imagens/fundo2.png)";
	paginainicial.style.display = 'none';
	document.getElementById('offline_pc').style.display = 'block';
	document.getElementById("easy").disabled = true;
	document.getElementById("medium").disabled = true;
	document.getElementById("hard").disabled = true;
}

/* Aparece as regras quando carregar no botão regras na página principal*/
document.getElementById("regras").addEventListener("click", function showregrasmenu(){
	regras();
});
function regras() {
	if(document.getElementById('op_regras').style.display == 'block')
		document.getElementById('op_regras').style.display = 'none';
	else
		document.getElementById('op_regras').style.display = 'block';
}

/* Aparece as regras quando carregar no botão regras na área de jogo*/
var modal = document.getElementById("mymodal");
// Quando o utilizador carrega no botão, abre a janela 
document.getElementById("show_regras").addEventListener("click", btnregras);
function btnregras() {
	modal.style.display = "block";
}
// Quando o utilizador carrega no <span> x, fecha a janela
document.getElementsByClassName("closeregras")[0].addEventListener("click", function span_regras(){
	spanregras();
});
function spanregras() {
	modal.style.display = "none";
}
// Quando o utilizador carrega em qualquer sitio sem ser na janela, fecha a janela
window.onclick = function(event) {
	if (event.target == modal) {
		modal.style.display = "none";
	}
}

function nome_user_pont(){
	var submit = document.getElementById("submit_user");
	var nomeuser = document.getElementById("user_cmpc");
	if(nomeuser.value == ""){
		window.alert("Utilizador inexistente!");
	}
	else{
		document.getElementById("utilizador_temp").style.display = "none";
		document.getElementById("nome_user").style.display = "block";
		document.getElementById("nome_user").innerHTML = "Pontuação " + nomeuser.value + ":";
		document.getElementById("user_cmpc").style.display = "none";
		document.getElementById("userText").style.display = "none";
		submit.style.display = "none";
		document.getElementById("easy").disabled = false;
		document.getElementById("medium").disabled = false;
		document.getElementById("hard").disabled = false;
	}
}

function show_mesa() {
	if(document.getElementById("submit_user").style.display == "none") {
		document.getElementById("easy").disabled = true;
		document.getElementById("medium").disabled = true;
		document.getElementById("hard").disabled = true;
		document.getElementById("mesa_pc").style.display = "block";
		document.getElementById("monte_pc").style.display = "block";
		document.getElementById("desistir").style.display = "block";
	}
	else {
		window.alert("Submissão inexistente!");
	}
}

// **********************************************************************************************

document.getElementById("loginPlayer").addEventListener("click",function logp(){
	logReg();
});

//SERVER CONNECTION
//var link = "http://twserver.alunos.dcc.fc.up.pt:8142"; // VERIFICAR
var link = "http://localhost:8142/";
var nameGlobal = "";
var passGlobal = "";
var groupGlobal = "groupMM";
var gameIdGlobal = "";

// REGISTER
function logReg(){
	score();
	var name = document.getElementById("user").value;
	var pass = document.getElementById("pass").value;

	nameGlobal = name;
	passGlobal = pass;
	conta = {
		nick : name,
		pass : pass
	}
	fetch(link + "register",{
		method : "POST",
		body : JSON.stringify(conta)
	})
	.then(function (resposta){
		return resposta.text();
	})
	.then(function (texto){
		if(texto != "{}") {
			console.log(texto);
			window.alert("Registo falhado por erro na password");
		}
		else if(name === "" || pass === "")
			window.alert("Preencha os campos");
		else {
			console.log(texto);
			show_pageON();
		}
	});
}

var paginainicial2 = document.getElementById('pagina_inicial');

function show_pageON() {
	document.body.style.backgroundImage = "url(files/imagens/fundo2.png)";
	paginainicial2.style.display = 'none';
	document.getElementById('online_jogo').style.display = 'block';
}

var playerHand = [];
var piecesOponente;
// JOIN
function pageON() {
	info_jogo = {
		group : groupGlobal,
		nick : nameGlobal,
		pass : passGlobal
	}
	fetch(link + "join", {
		method : "POST",
		body : JSON.stringify(info_jogo)
	})
	.then(function (resposta){
		return resposta.json();
	})
	.then(function (texto){
		gameIdGlobal = texto.game;
		if(texto.hand == null){
			sair();
			pageON();
			return;
		}
		addaptHand(texto.hand);
		console.log(texto);
		show_mesaON();
		// start();
	});
}

function addaptHand(arr){
	for(var i=0; i<arr.length; i++){
		playerHand[i] = new Peca(arr[i][0],arr[i][1]);
	}
	console.log(playerHand);
}

document.getElementById("start_game").addEventListener("click", function playStart() {
	pageON();
	atualizar();
});

function show_mesaON() {
	document.getElementById("start_game").style.display = "none";
	document.getElementById("mesaON").style.display = "block";
	document.getElementById("monte_ONLINE").style.display = "block";
	document.getElementById("desistirON").style.display = "block";
	printMount();
	print_mesa();
}

/* Aparece as regras quando carregar no botão regras na área de jogo do ONLINE*/
var modal_regrasOn = document.getElementById("mymodalON");
// Quando o utilizador carrega no botão, abre a janela 
document.getElementById("show_regrasON").addEventListener("click", btnregrasOn);
function btnregrasOn() {
	modal_regrasOn.style.display = "block";
}
// Quando o utilizador carrega no <span> x, fecha a janela
document.getElementsByClassName("closeregrason")[0].addEventListener("click", function span_regrasOn(){
	spanregrason();
});
function spanregrason() {
	modal_regrasOn.style.display = "none";
}
// Quando o utilizador carrega em qualquer sitio sem ser na janela, fecha a janela
window.onclick = function(event) {
	if (event.target == modal) {
		modal.style.display = "none";
	}
}

// NOTIFY
function notify_pedir() {
	info_jogo = {
		nick : nameGlobal,
		pass : passGlobal,
		game : gameIdGlobal,
		piece : null
	}
	fetch(link + "notify", {
		method : "POST",
		body : JSON.stringify(info_jogo)
	})
	.then(function (resposta){
		return resposta.json();
	})
	.then(function (texto){
		console.log(texto.piece);
	});
}

function notify_jogar(piece, side) {
	info_jogo = {
		nick : nameGlobal,
		pass : passGlobal,
		game : gameIdGlobal,
		piece : piece,
		side : side
	}
	fetch(link + "notify", {
		method : "POST",
		body : JSON.stringify(info_jogo)
	})
	.then(function (resposta){
		return resposta.json();
	})
	.then(function (texto){
		console.log(texto.piece);
	});
}

function notify_passar() {
	info_jogo = {
		nick : nameGlobal,
		pass : passGlobal,
		game : gameIdGlobal,
		skip : null
	}
	fetch(link + "notify", {
		method : "POST",
		body : JSON.stringify(info_jogo)
	})
	.then(function (resposta){
		return resposta.json();
	})
	.then(function (texto){
		console.log(texto);
	});
}

// UPDATE
var turno = 0; // 0 -> oponente && 1 -> utilizador
var monte;
var mesa = [];
function atualizar() {
	eventSource = new EventSource(encodeURI(link + "update?game" + gameIdGlobal + "&nick" + nameGlobal));
	eventSource.onmessage = function(event) {
		const data = JSON.parse(event.data);

		if(data.error)
			window.alert("ERROR!");
		else if(data.winner) {
			mesa_clean();
			if(data.winner == nameGlobal) {
				window.alert("Venceu!");
			}
			else {
				window.alert("Perdeu!");
			};
			sair();
			eventSource.close();
			return;
		}

		else if(data.board.line != null) {
			if(data.turn == nameGlobal) {
				if(data.board.line.lenght == 0){
					maxPiece();
					print_mesa();
				}
				else {
					checkPlay();
					monte = data.board.stock;
					check();
				}
			}
				
			// ...
			monte = data.board.stock;
			playerHand.length = data.board.count[nameGlobal];
			if(mesa.length > 0) {
				// ...
				// ...
			}
		}
		else if(data.turn && data.board) {
			// ...
			monte = data.board.stock;
			playerHand.length = data.count;
			if(data.turn == nameGlobal) {
				turno = 1;
				var pos, val, maxVALUE = 0;
				if(n == 0) {
					// ...
				}
			}
			else
				turno = 0;
		}
	}
}

function mesa_clean() {
	document.getElementById("jogo_oponenteON").innerHTML = "";
	document.getElementById("jogo_utilizadorON").innerHTML = "";
	document.getElementById("jogo").innerHTML = "";
	document.getElementById("monte_ONLINE").innerHTML = "";
}

function maxPiece() {
	var max = 0;
	var pos;
	for(var i = 0; i < playerHand.length; i++) {
		var soma = playerHand[i].left + playerHand[i].right;
		if(soma >= max) {
			max = soma;
			pos = i;
		}
	}
	var arr = [playerHand[pos].left, playerHand[pos].right];
	console.log(arr);
	notify_jogar(arr, "start");
	document.getElementById("jogo_utilizadorON").removeChild(document.getElementById("jogo_utilizadorON").childNodes[pos]);
	playerHand.splice(pos, 1);
}

function checkPlay() {
	for(var i = 0; i < playerHand.length; i++) {
		if(playerHand[i].left == mesa[0].left) {
			return 1;
		}
		if(playerHand[i].right == mesa[0].left) {
			return 2;
		}
		if(playerHand[i].left == mesa[mesa.length-1].right) {
			return 3;
		}
		if(playerHand[i].right == mesa[mesa.length-1].right) {
			return 4;
		}
	}
	return -1;
}

function check() {
	if(checkPlay() == -1 && monte == 0) {
		notify_passar();
	}
	else if(checkPlay() == -1 && monte != 0) {
		notify_pedir();
	}
	else {
		return;
	}
}

function print_mesa() {
	// piecesOponente = 28 - board.stock - playerHand.length - board.line.length;
	// for(var i = 0; i < piecesOponente; i++) {
	// 	var elem = document.createElement("span");
 // 		elem.innerHTML = "&#" + 127074;
	// 	document.getElementById("jogo_oponenteON").appendChild(elem);
	// }
	// for(var i = 0; i < mesa.length; i++) {
	// 	mesa[i] = board.tabuleiro[i];
 // 		var contas = 127025+mesa[i].left*7+mesa[i].right;
 // 		if(mesa[i].left == mesa[i].right) 
 // 			contas += 50;
 // 		var elem = document.createElement("span");
 // 		elem.innerHTML = "&#" + contas;
 // 		document.getElementById("jogoON").appendChild(elem);
	// }
	for(var i = 0; i < playerHand.length; i++) {
 		var contas = 127025+playerHand[i].left*7+playerHand[i].right+50;
 		var elem = document.createElement("span");
 		var idp;
 		idp = "" + playerHand[i].left + "" + playerHand[i].right + "";
 		elem.setAttribute("id","peca("+idp+")");
 		elem.setAttribute("onclick", "play("+idp+")");
 		elem.innerHTML = "&#" + contas;
 		document.getElementById("jogo_utilizadorON").appendChild(elem);
	}
	// Imprimir o monte
 
}

// LEAVE
function sair() {
	desistir = {
		nick : nameGlobal,
		pass : passGlobal,
		game : gameIdGlobal
	}
	fetch(link + "leave", {
		method : "POST",
		body : JSON.stringify(desistir)
	})
	.then(function (resposta){
		return resposta.text();
	})
	.then(function (texto){
		console.log(texto);
		console.log("logout");
		mesa_clean();
	});
}

document.getElementById("desistirON").addEventListener("click", function() {
	sair();
	document.getElementById("user").innerHTML = "";
	document.getElementById("pass").innerHTML = "";
	paginainicial.style.display = 'block';
	document.body.style.backgroundImage = "url(files/imagens/fundo.png)";
	modal_on.style.display = "none";
	document.getElementById('online_jogo').style.display = 'none';
});

// RANKING
function score() {
	fetch(link + "ranking", {
		method : "POST",
		body : JSON.stringify("")
	})
	.then(function (resposta){
		return resposta.json();
	})
	.then(function (texto){
		printRanks(texto.ranking);
	});
}

var modal_pontON = document.getElementById("table_pont");
// Quando o utilizador carrega no botão, abre a janela 
document.getElementById("pontuacaoON").addEventListener("click", btnpontON);
function btnpontON() {
	modal_pontON.style.display = "block";
}
// Quando o utilizador carrega no <span> x, fecha a janela
document.getElementsByClassName("close_pontON")[0].addEventListener("click", function spanpontON(){
	span_pontON();
});
function span_pontON() {
	modal_pontON.style.display = "none";
}

function printRanks(arr){
	var tab = document.getElementById("tab_raking");

	while(tab.firstChild){
		tab.removeChild(tab.firstChild);
	}
	var trM = document.createElement("tr");
	var th1 = document.createElement("th");
	var th2 = document.createElement("th");
	var th3 = document.createElement("th");
	th1.innerHTML = "Nome utilizador";
	th2.innerHTML = "Vitorias";
	th3.innerHTML = "Jogos";
	trM.appendChild(th1);
	trM.appendChild(th2);
	trM.appendChild(th3);
	tab.appendChild(trM);

	for(var i =0 ; i<arr.length; i++){
		var trI = document.createElement("tr");
		var thI1 = document.createElement("th");
		var thI2 = document.createElement("th");
		var thI3 = document.createElement("th");
		thI1.innerHTML = arr[i].nick;
		thI2.innerHTML = arr[i].victories;
		thI3.innerHTML = arr[i].games;
		trI.appendChild(thI1);
		trI.appendChild(thI2);
		trI.appendChild(thI3);
		tab.appendChild(trI);
	}
}

//--------------------

//PLAYER VS PLAYER ALGORITHM

function play(id) {
	if(turno==0) return;

	if(id == "0")
		id = "00";
	if(id == "1")
		id = "01";
	if(id == "2")
		id = "02";
	if(id == "3")
		id = "03";
	if(id == "4")
		id = "04";
	if(id == "5")
		id = "05";
	if(id == "6")
		id = "06";

	console.log("Vez_do_User");
	var children = document.getElementById("jogo_utilizadorON").childNodes;
	var aux;
	var i;
	for(i=0; i<children.length; i++){
		if(children[i].id === "peca("+id+")") {
			aux=i;
			break;
		}
	}
	var childPos = children[aux];
	var jogada = verifyClick(playerHand[aux],mesa[0].left,mesa[mesa.length-1].right);
	if(jogada == -1)return;

	if(jogada == 2 || jogada == 4){
		var contas;
		if(playerHand[aux].right === playerHand[aux].left)
			contas = 127025+playerHand[aux].left*7+playerHand[aux].right+50;
		else
			contas = 127025+playerHand[aux].right*7+playerHand[aux].left;

		var elem = document.createElement("span");
		elem.innerHTML = "&#" + contas;

		if(jogada == 2){

			mesa.unshift(new Peca(playerHand[aux].right,playerHand[aux].left));
			document.getElementById("jogoON").insertBefore(elem,document.getElementById("jogoON").childNodes[0]);
			document.getElementById("jogo_utilizadorON").removeChild(childPos);
			playerHand.splice(aux,1);
		}
		else if(jogada == 4) {

			mesa.push(new Peca(playerHand[aux].right,playerHand[aux].left));
			document.getElementById("jogoON").appendChild(elem);
			document.getElementById("jogo_utilizadorON").removeChild(childPos);
			playerHand.splice(aux,1);
		}
	}

	else if(jogada == 3){
		var contas;
		if(playerHand[aux].right === playerHand[aux].left)
			contas = 127025+playerHand[aux].left*7+playerHand[aux].right+50;
		else
			contas = 127025+playerHand[aux].left*7+playerHand[aux].right;
		var elem = document.createElement("span");
		elem.innerHTML = "&#" + contas;
		mesa.unshift(playerHand[aux]);
		document.getElementById("jogoON").insertBefore(elem,document.getElementById("jogoON").childNodes[0]);
		document.getElementById("jogo_utilizadorON").removeChild(childPos);
		playerHand.splice(aux,1);
	}

	else if(jogada == 1){
		var contas;
		if(playerHand[aux].right === playerHand[aux].left)
			contas = 127025+playerHand[aux].left*7+playerHand[aux].right+50;
		else
			contas = 127025+playerHand[aux].left*7+playerHand[aux].right;
		var elem = document.createElement("span");
		elem.innerHTML = "&#" + contas;
		mesa.push(playerHand[aux]);
		document.getElementById("jogoON").appendChild(elem);
		document.getElementById("jogo_utilizadorON").removeChild(childPos);
		playerHand.splice(aux,1);
	}
	aparecer_passar();
	turno = 0;
}

function verifyClick(peca,l,r){ //peca|tab : 1->esq|dir ; 2->esq|esq; 3->dir|esq; 4->dir|dir
	console.log(peca);
	if(peca.left === r) return 1;
	if(peca.left === l) return 2;
	if(peca.right === l) return 3;
	if(peca.right === r) return 4;

	return -1;
}

function printMount(){
var elem1 = document.createElement("span");
 	elem1.setAttribute("onclick", "irMonte()");
 	elem1.innerHTML = "&#127074;" + 14;

 	document.getElementById("monteON").appendChild(elem1);
}
// // Utilizador ir buscar ao monte
function irMonte() {
	if(monte.length == 0) return;
	var i;
	for(i = 0; i < playerHand.length; i++) {
		if(verifyClick(playerHand[i], mesa[0].left, mesa[mesa.length-1].right) != -1) {
			window.alert("Olhe com mais atenção para o seu jogo");
			return;
		}
	}
	console.log("Monte");
	while(monte.length > 0){ // ir buscar monte
		var childs = document.getElementById("monteON").childNodes;
		var child = childs[0];
		child.innerHTML = "";
		child.innerHTML = "&#127074;" + monte;
		var idp;
		var pos_random = Math.floor(Math.random()*monte.length);
		if(verifyClick(monte[pos_random], mesa[0].left, mesa[jogo.length-1].right)!=-1) { // quando puder jogar uma peça
			playerHand.push(monte[pos_random]);
			idp = "" + monte[pos_random].left + "" + monte[pos_random].right + "";
			var contas = 50+127025+monte[pos_random].left*7+monte[pos_random].right;
			var elem = document.createElement("span");
			elem.setAttribute("id","peca("+playerHand[playerHand.length-1].left +""+ playerHand[playerHand.length-1].right +")");
			elem.setAttribute("onclick", "play("+idp+")");
			elem.innerHTML = "&#" + contas;
			document.getElementById("jogo_utilizadorON").appendChild(elem);
			break;
		}
		else { // enquanto não consegue jogar nenhuma peça
			user.push(pecas[pos_random]);
			idp = "" + pecas[pos_random].left + "" + pecas[pos_random].right + "";
			var contas = 50+127025+pecas[pos_random].left*7+pecas[pos_random].right;
			var elem = document.createElement("span");
			elem.setAttribute("id","peca("+user[user.length-1].left +""+ user[user.length-1].right +")");
			elem.setAttribute("onclick", "jogar("+idp+")");
			elem.innerHTML = "&#" + contas;
			document.getElementById("jogo_utilizador").appendChild(elem);
			pecas.splice(pos_random,1);
		}
	}
	var childs = document.getElementById("monte").childNodes;
		var child = childs[0];
		child.innerHTML = "";
		child.innerHTML = "&#127074;" + pecas.length;
}

document.getElementById("passarON").addEventListener("click", notify_passar);

function aparecer_passar() {
	if(monte == 0) {
		document.getElementById("passarON").style.display = 'block';
		document.getElementById("monte_ONLINE").style.display = 'none';
	}
}

//--------------------
