var tabela = [
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 1, 2, 0, 0, 0, 0],
  [0, 0, 0, 0, 2, 1, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
];


document.getElementById(44).className = "peca branca";
document.getElementById(55).className = "peca branca";
document.getElementById(45).className = "peca preto";
document.getElementById(54).className = "peca preto";

var pontos1=20;
var pontos2=20;
var pontos_branco= document.getElementById('branco')
var pontos_preto=document.getElementById('preto')
 
var x = 2;
var pecas=0;
function inserir_peca(y_coord, x_coord) {
if(tabela[y_coord][x_coord]!=0)
{
  //window.alert("Essa posição já possui peça.");
  //return false;
  throw new Error("Essa posição ja possui peça"); // Erro invisivel mas window.alert nao funciona neste caso e usar return faz o mesmo porque nao para a função.
  // Evita que a vez passe caso o jogador jogue uma cell que já possui uma peça.
}
  var pecas = 4;
  var m;
    if (x == 1)
    {
        if (tabela[y_coord-1][x_coord] == 2 /*|| tabela[y_coord-1][x_coord-1] == 2*/ || tabela[y_coord][x_coord-1] == 2
        /*|| tabela[y_coord+1][x_coord-1] == 2*/ || tabela[y_coord+1][x_coord] == 2 /*|| tabela[y_coord+1][x_coord+1] == 2*/
        || tabela[y_coord][x_coord+1] == 2 /*|| tabela[y_coord-1][x_coord+1] == 2*/ )
           {
             pontos1 +=10;
            tabela[y_coord][x_coord] = 1;
             document.getElementById('vez_branca').style.display = 'block';
             document.getElementById('vez_preto').style.display = 'none';
             var id = y_coord + "" + x_coord;
             console.log("y:%d x:%d",y_coord,x_coord);
             document.getElementById(id).className = "peca branca";
              atualizar_tabuleiro(y_coord,x_coord,1);
              pontos2 +=10;
              pontos1 -=10;
              pontos_branco.innerHTML= pontos1;
              pontos_preto.innerHTML= pontos2;

          }
      else {
          throw new Error("Posiçao mal jogada "); // Evita que a vez passe caso o jogador jogue uma peça indisponivel.
      }
      x = 2;
    }
    else if (x == 2 )
    {
         if (tabela[y_coord-1][x_coord] == 1 /*|| tabela[y_coord-1][x_coord-1] == 1 */|| tabela[y_coord][x_coord-1] == 1
         /*|| tabela[y_coord+1][x_coord-1] == 1 */|| tabela[y_coord+1][x_coord] == 1 /*|| tabela[y_coord+1][x_coord+1] == 1*/
         || tabela[y_coord][x_coord+1] == 1 /*|| tabela[y_coord-1][x_coord+1] == 1 */)
            {
              pontos2 +=10;
              tabela[y_coord][x_coord] = 2;
              document.getElementById('vez_preto').style.display='block';
              document.getElementById('vez_branca').style.display = 'none';
             var id = y_coord + "" + x_coord;
             console.log("y:%d x:%d",y_coord,x_coord);
             document.getElementById(id).className = "peca preto";
             atualizar_tabuleiro(y_coord,x_coord,2);
             pontos1 +=10;
             pontos2 -=10;
             pontos_branco.innerHTML= pontos1;
             pontos_preto.innerHTML= pontos2;
           }
        else {
              throw new Error("Posiçao mal jogada "); // Evita que a vez passe caso o jogador jogue uma peça indisponivel.
        }
      x = 1;
    }
    console.log("Inicio");
    imprimir_tabela();
    console.log("Fim");
}


function virar_pecas_horizontal(y_m,inicio,fim,vez)

{
  for(var j=inicio;j<fim;j++)
  {
    var id = y_m + "" + j;
    if(vez==1)
    {
      tabela[y_m][j]=1;
      document.getElementById(id).className = "peca branca";
      pontos2 -=10;
      pontos1 +=10;
    }
    else if(vez==2)
    {
      tabela[y_m][j]=2;
      document.getElementById(id).className = "peca preto";
      pontos1 -=10;
      pontos2 +=10;
    }
  }
}

function virar_pecas_vertical(x_m,inicio,fim,vez)
{
  for(var j=inicio;j<fim;j++)
  {
    var id = j + "" + x_m;
    if(vez==1)
    {
      tabela[j][x_m]=1;
      document.getElementById(id).className = "peca branca";
      pontos2 -=10;
      pontos1 +=10;
    }
    else if(vez==2)
    {
      tabela[j][x_m]=2;
      document.getElementById(id).className = "peca preto";
      pontos1 -=10;
      pontos2 +=10;
    }
  }
}

function atualizar_tabuleiro(y_m,x_m,vez)
{
  // linhas horizontais
  var k_d=x_m+1;

    for(;k_d<=8;k_d++)  // linha horizontal direita
    {
      if(tabela[y_m][k_d]==0)break;
      if(tabela[y_m][k_d]==vez)
      {
        //console.log("Condiçao aceite");
        virar_pecas_horizontal(y_m,x_m,k_d,vez);
        return;
      }
    }

    var k_e=x_m-1;
    for(;k_e>=1;k_e--)  // linha horizontal esquerda
    {
      if(tabela[y_m][k_e]==0)break;
      if(tabela[y_m][k_e]==vez)
      {
        //console.log("Condiçao aceite");
        virar_pecas_horizontal(y_m,k_e,x_m,vez);
        return;
      }
    }

    var k_c=y_m+1;
    for(;k_c<=8;k_c++) // vertical cima
    {
      if(tabela[k_c][x_m]==0)break;
      if(tabela[k_c][x_m]==vez)
      {
        //console.log("Condiçao aceite");
        virar_pecas_vertical(x_m,y_m,k_c,vez);
        return;
      }
    }

    var k_b=y_m-1;
    for(;k_b>=1;k_b--)
    {
      if(tabela[k_b][x_m]==0)break;
      if(tabela[k_b][x_m]==vez) // vertical baixo
      {
        //console.log("Condiçao aceite");
        virar_pecas_vertical(x_m,k_b,y_m,vez);
        return;
      }
    }

    
}


function imprimir_tabela()
{
/*  for(var i=0;i<8;i++)
  {
    for(var k=0;k<8;k++)
    {
      if(tabela[i][k]!=0)
      {
      console.log("y:%d x:%d valor:%d",i,k,tabela[i][k]);
    }
    }
  }*/
  console.log(tabela);
}


function selecionar_cell(y_coord, x_coord) {
  var id = y_coord + "" + x_coord;
  if (x ==1) {
    inserir_peca(y_coord, x_coord);
    x = 2;
  }
  else if (x==2) {
    inserir_peca(y_coord, x_coord);
    x = 1;
  }
  pecas++;
}
