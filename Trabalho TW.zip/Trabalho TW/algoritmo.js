var tabela = [
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 1, 2, 0, 0, 0],
  [0, 0, 0, 2, 1, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0]
];

document.getElementById(27).className = "branca";
document.getElementById(36).className = "branca";
document.getElementById(28).className = "preto";
document.getElementById(35).className = "preto";

function selecionar_cell(cell)
{
   document.getElementById(cell).className = "branca";
   if(cell==3)
   {
   document.getElementById(cell).className = "preto";
   }
}
