var tabela = [
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 1, 2, 0, 0, 0],
  [0, 0, 0, 2, 1, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0]
];

document.getElementById(33).className = "peca branca";
document.getElementById(44).className = "peca branca";
document.getElementById(34).className = "peca preto";
document.getElementById(43).className = "peca preto";


function inserir_peca(rows,cols) {

  var pecas = 4;
  var x=2;
  while (pecas < 64)
  {
    if(x==1){
  /*  if (tabela[rows-1][cols-1] != 0 || tabela[rows-1][cols] != 0 ||tabela[rows+1][cols] != 0 ||
      tabela[rows][cols-1] != 0 ||tabela[rows][cols+1] != 0 ||
      tabela[rows-1][cols+1] != 0 ||tabela[rows+1][cols-1] != 0 ||
      tabela[rows+1][cols+1] != 0 ||tabela[rows+1][cols] != 0)
      {*/
      window.alert("rows+cols");
      selecionar_cell(rows+cols, x);
    //}
    x=2;
  }
  else if(x==2)
  {
/*    if (tabela[rows-1][cols-1] != 0 || tabela[rows-1][cols] != 0 ||tabela[rows+1][cols] != 0 ||
      tabela[rows][cols-1] != 0 ||tabela[rows][cols+1] != 0 ||
      tabela[rows-1][cols+1] != 0 ||tabela[rows+1][cols-1] != 0 ||
      tabela[rows+1][cols+1] != 0 ||tabela[rows+1][cols] != 0)
      {*/
      selecionar_cell(rows+cols, x);
  //  }
    x=1;
  }


  pecas++;
}
}



function selecionar_cell(cell, x) {
  if (x == 1)
    document.getElementById(cell).className = "peca branca";
  else if (x == 2) {
    document.getElementById(cell).className = "peca preto";
  }
}
