var tabela = [
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 1, 2, 0, 0, 0, 0],
  [0, 0, 0, 0, 2, 1, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
];


document.getElementById(44).className = "peca branca";
document.getElementById(55).className = "peca branca";
document.getElementById(45).className = "peca preto";
document.getElementById(54).className = "peca preto";

var x = 2;
var pecas=0;
function inserir_peca(y_coord, x_coord) {
if(tabela[y_coord][x_coord]!=0)
{
  //window.alert("Essa posição já possui peça.");
  //return false;
  throw new Error("Essa posição ja possui peça"); // Erro invisivel mas window.alert nao funciona neste caso e usar return faz o mesmo porque nao para a função.
  // Evita que a vez passe caso o jogador jogue uma cell que já possui uma peça.
}
  var pecas = 4;
  var m;
    if (x == 1)
    {
        if (tabela[y_coord-1][x_coord] != 0 || tabela[y_coord-1][x_coord-1] != 0 || tabela[y_coord][x_coord-1] != 0
        || tabela[y_coord+1][x_coord-1] != 0 || tabela[y_coord+1][x_coord] != 0 || tabela[y_coord+1][x_coord+1] != 0
        || tabela[y_coord][x_coord+1] != 0 || tabela[y_coord-1][x_coord+1] != 0 )
           {
             document.getElementById('vez_branca').style.display = 'block';
             document.getElementById('vez_preto').style.display = 'none';
             var id = y_coord + "" + x_coord;
             tabela[y_coord][x_coord] = 1;
             console.log("y:%d x:%d",y_coord,x_coord);
             document.getElementById(id).className = "peca branca";
          }
      else {
          throw new Error("Posiçao mal jogada "); // Evita que a vez passe caso o jogador jogue uma peça indisponivel.
      }
      x = 2;
    }
    else if (x == 2 )
    {
         if (tabela[y_coord-1][x_coord] != 0 || tabela[y_coord-1][x_coord-1] != 0 || tabela[y_coord][x_coord-1] != 0
         || tabela[y_coord+1][x_coord-1] != 0 || tabela[y_coord+1][x_coord] != 0 || tabela[y_coord+1][x_coord+1] != 0
         || tabela[y_coord][x_coord+1] != 0 || tabela[y_coord-1][x_coord+1] != 0 )
            {
              document.getElementById('vez_preto').style.display='block';
              document.getElementById('vez_branca').style.display = 'none';
             var id = y_coord + "" + x_coord;
             tabela[y_coord][x_coord] = 2;
             console.log("y:%d x:%d",y_coord,x_coord);
             document.getElementById(id).className = "peca preto";
           }
        else {
              throw new Error("Posiçao mal jogada "); // Evita que a vez passe caso o jogador jogue uma peça indisponivel.
        }
      x = 1;
    }
    console.log("Inicio");
    imprimir_tabela();
    console.log("Fim");
}


function imprimir_tabela()
{
/*  for(var i=0;i<8;i++)
  {
    for(var k=0;k<8;k++)
    {
      if(tabela[i][k]!=0)
      {
      console.log("y:%d x:%d valor:%d",i,k,tabela[i][k]);
    }
    }
  }*/
  console.log(tabela);
}


function selecionar_cell(y_coord, x_coord) {
  var id = y_coord + "" + x_coord;
  if (x ==1) {
    inserir_peca(y_coord, x_coord);
    x = 2;
  }
  else if (x==2) {
    inserir_peca(y_coord, x_coord);
    x = 1;
  }
  pecas++;
}
