var tabela = [
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 1, 2, 0, 0, 0],
  [0, 0, 0, 2, 1, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0]
];

document.getElementById(33).className = "peca branca";
document.getElementById(44).className = "peca branca";
document.getElementById(34).className = "peca preto";
document.getElementById(43).className = "peca preto";

var x = 2;
function inserir_peca(x_coord, y_coord) {

  var pecas = 4;
  var m;
  while (pecas < 64) {
    if (x == 1) {
      /*  if (tabela[rows-1][cols-1] != 0 || tabela[rows-1][cols] != 0 ||tabela[rows+1][cols] != 0 ||
          tabela[rows][cols-1] != 0 ||tabela[rows][cols+1] != 0 ||
          tabela[rows-1][cols+1] != 0 ||tabela[rows+1][cols-1] != 0 ||
          tabela[rows+1][cols+1] != 0 ||tabela[rows+1][cols] != 0)
          {*/

      // window.alert(rows+cols);
      var id = x_coord + "" + y_coord;
      // window.alert(rows+cols);
      console.log(id);
      if (tabela[x_coord][y_coord] == 0) {
        tabela[x_coord][y_coord] = 2;
        document.getElementById(id).className = "peca branca";

      }
      //   selecionar_cell(m.toString(), x);
      //}
      x = 2;
    }
    else if (x == 2) {
      /*    if (tabela[rows-1][cols-1] != 0 || tabela[rows-1][cols] != 0 ||tabela[rows+1][cols] != 0 ||
            tabela[rows][cols-1] != 0 ||tabela[rows][cols+1] != 0 ||
            tabela[rows-1][cols+1] != 0 ||tabela[rows+1][cols-1] != 0 ||
            tabela[rows+1][cols+1] != 0 ||tabela[rows+1][cols] != 0)
            {*/
      var id = x_coord + "" + y_coord;
      // window.alert(rows+cols);
      console.log(id);
      if (tabela[x_coord][y_coord] == 0) {
        tabela[x_coord][y_coord] = 2;
        document.getElementById(id).className = "peca preto";

      }
      //  }
      x = 1;
    }


    pecas++;
  }
}



function selecionar_cell(x_coord, y_coord) {
  var id = x_coord + "" + y_coord;
  if (x == 1) {
    inserir_peca(x_coord, y_coord);
    x = 2;
  }
  else if (x == 2) {
    inserir_peca(x_coord, y_coord);
    x = 1;
  }
}
