var tabela = [
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 1, 2, 0, 0, 0],
  [0, 0, 0, 2, 1, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0]
];

document.getElementById(33).className = "peca branca";
document.getElementById(44).className = "peca branca";
document.getElementById(34).className = "peca preto";
document.getElementById(43).className = "peca preto";

var x = 2;
function inserir_peca(y_coord, x_coord) {
if(tabela[y_coord][x_coord]!=0)
{
  //window.alert("Essa posição já possui peça.");
  //return false;
  throw new Error("Essa posição ja possui peça"); // Erro invisivel mas window.alert nao funciona neste caso e usar return faz o mesmo porque nao para a função.
  // Evita que a vez passe caso o jogador jogue uma cell que já possui uma peça.
}
  var pecas = 4;
  var m;
  while (pecas < 64) {
    if (x == 1)
    {
        document.getElementById('vez_branca').style.display = 'block';
        document.getElementById('vez_preto').style.display = 'none';
        if (tabela[y_coord+1][x_coord] != 0 || tabela[y_coord+1][x_coord-1] != 0 || tabela[y_coord][x_coord-1] != 0
          || tabela[y_coord-1][x_coord] != 0
          || tabela[y_coord-1][x_coord+1] != 0  || tabela[y_coord][x_coord+1] != 0 || tabela[y_coord+1][x_coord+1] != 0 )
          {
      var id = y_coord + "" + x_coord;
      if (tabela[y_coord][x_coord] == 0)
      {
        tabela[y_coord][x_coord] = 1;
        console.log("y:%d x:%d",y_coord,x_coord);
        document.getElementById(id).className = "peca branca";
       }
      }
      else {
          throw new Error("Posiçao mal jogada "); // Evita que a vez passe caso o jogador jogue uma peça indisponivel.
      }
      x = 2;
    }
    else if (x == 2 )
    {
         document.getElementById('vez_preto').style.display='block';
         document.getElementById('vez_branca').style.display = 'none';
         if (tabela[y_coord+1][x_coord] != 0 || tabela[y_coord+1][x_coord-1] != 0 || tabela[y_coord][x_coord-1] != 0
           || tabela[y_coord-1][x_coord-1] != 0 || tabela[y_coord-1][x_coord] != 0
           || tabela[y_coord-1][x_coord+1] != 0  || tabela[y_coord][x_coord+1] != 0 || tabela[y_coord+1][x_coord+1] != 0 )
            {
      var id = y_coord + "" + x_coord;
     if (tabela[y_coord][x_coord] == 0) {
        tabela[y_coord][x_coord] = 2;
        console.log("y:%d x:%d",y_coord,x_coord);
        document.getElementById(id).className = "peca preto";
         }
        }
        else {
              throw new Error("Posiçao mal jogada "); // Evita que a vez passe caso o jogador jogue uma peça indisponivel.
        }
      x = 1;
    }
    pecas++;
  }
}


function selecionar_cell(y_coord, x_coord) {
  var id = y_coord + "" + x_coord;
  if (x ==1) {
    inserir_peca(y_coord, x_coord);
    x = 2;
  }
  else if (x==2) {
    inserir_peca(y_coord, x_coord);
    x = 1;
  }
}
