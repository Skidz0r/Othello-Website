var tabela = [
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 1, 2, 0, 0, 0],
  [0, 0, 0, 2, 1, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0]
];


document.getElementById(33).className = "peca branca";
document.getElementById(44).className = "peca branca";
document.getElementById(34).className = "peca preto";
document.getElementById(43).className = "peca preto";

var x = 2;
var pecas = 0;
function inserir_peca(y_coord, x_coord) {
  /*if (tabela[y_coord][x_coord] != 0) {
    throw new Error("Essa posição já possui peça.");
  }*/

  var pecas = 4;
  var m;
  var verify = 0;
  while(pecas <65){
    verify=0;
  if (x == 1) {
    while (verify == 0) {
      console.log(verify);
      if (tabela[y_coord - 1][x_coord - 1] == 2  || tabela[y_coord ][x_coord - 1] == 2 ||
        tabela[y_coord - 1][x_coord] == 2 || tabela[y_coord + 1][x_coord + 1] == 2 ||
        tabela[y_coord + 1][x_coord ] == 2 || tabela[y_coord][x_coord + 1] == 2 ||
        tabela[y_coord + 1][x_coord - 1] == 2 || tabela[y_coord - 1][x_coord + 1] == 2) {
        var id = y_coord + "" + x_coord;
        tabela[y_coord][x_coord] = 1;
        console.log("y:%d x:%d", y_coord, x_coord);
        document.getElementById(id).className = "peca branca";
        //window.alert("vai te lixar");   

        verify = 1;
      }
    }
    /* else {
         throw new Error("Posiçao mal jogada "); // Evita que a vez passe caso o jogador jogue uma peça indisponivel.
     }*/
    x = 2;
  }
  if(x==2) {
    while (verify == 0) {
      console.log(verify);
      if (tabela[y_coord - 1][x_coord - 1] == 1  || tabela[y_coord ][x_coord - 1] == 1 ||
         tabela[y_coord - 1][x_coord] == 1 || tabela[y_coord + 1][x_coord + 1] == 1 ||
         tabela[y_coord + 1][x_coord ] == 1 || tabela[y_coord][x_coord + 1] == 1 ||
         tabela[y_coord + 1][x_coord - 1] == 1 || tabela[y_coord - 1][x_coord + 1] == 1) {
        var id = y_coord + "" + x_coord;
        tabela[y_coord][x_coord] = 2;
        console.log("y:%d x:%d", y_coord, x_coord);
        document.getElementById(id).className = "peca preto";
        verify=1;
        //window.alert("vai te lixar");
      }
      else{
        verify =0;
        //throw new Error(verify);
      }
    }
    /*else {
          throw new Error("Posiçao mal jogada "); // Evita que a vez passe caso o jogador jogue uma peça indisponivel.
    }*/
    x = 1;
  }
  pecas++;
}
  console.log("Inicio");
  imprimir_tabela();
  console.log("Fim");
}


function imprimir_tabela() {
  /*  for(var i=0;i<8;i++)
    {
      for(var k=0;k<8;k++)
      {
        if(tabela[i][k]!=0)
        {
        console.log("y:%d x:%d valor:%d",i,k,tabela[i][k]);
      }
      }
    }*/
  console.log(tabela);
}

function selecionar_cell(y_coord, x_coord) {
  var id = y_coord + "" + x_coord;
  if (x == 1) {
    inserir_peca(y_coord, x_coord);
    x = 2;
  }
  else if (x == 2) {
    inserir_peca(y_coord, x_coord);
    x = 1;
  }
  pecas++;
}
