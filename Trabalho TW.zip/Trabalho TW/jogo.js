
function vai() {
    var x = document.getElementById('rulesText');
       if (x.style.display === 'none') {
           x.style.display = 'block';
       } else {
           x.style.display = 'none';
       }
 }


 function onl(){
    var x = document.getElementById('online_text');
       if (x.style.display === 'none') {
           x.style.display = 'block';
       } else {
           x.style.display = 'none';
       }

 }

var x = document.getElementById('online_text');
 document.getElementById('close').addEventListener('click', function(){
    x.style.display ='none';
 });

