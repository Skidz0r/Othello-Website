function password()
{
  var x = document.getElementById("minha_pass");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}


 function onl(){ // função para fechar botão online
    var x = document.getElementById('online_text');
       if (x.style.display === 'none') {
           x.style.display = 'block';
       } else {
           x.style.display = 'none';
       }
 }

 function off(){  // função para fechar botão offline
    var y = document.getElementById('offline_text');
       if (y.style.display === 'none') {
           y.style.display = 'block';
       } else {
           y.style.display = 'none';
       }
 }

 function rules(){  // função para fechar botão regras
    var z = document.getElementById('rules_text');
       if (z.style.display === 'none') {
           z.style.display = 'block';
       } else {
           z.style.display = 'none';
       }
 }

var x = document.getElementById('online_text');
 document.getElementById('close_online').addEventListener('click', function(){
    x.style.display ='none';
 });

 var y = document.getElementById('offline_text');
  document.getElementById('close_offline').addEventListener('click', function(){
     y.style.display ='none';
  });

  var z = document.getElementById('rules_text');
   document.getElementById('close_rules').addEventListener('click', function(){
      z.style.display ='none';
   });


 document.getElementById('computador').addEventListener('click', function()
 {
     document.getElementById('total').style.display = 'none';
     document.getElementById('game').style.display = 'block';
     document.getElementById('logo-inicial').style.display='none';
     document.getElementById('area-principal').style.display='block';
     document.getElementById('vez_preto').style.display = 'block';
});

document.getElementById('amigo').addEventListener('click', function()
{
window.alert("Futuramente disponivel");
});
