document.getElementById("rules").addEventListener("click",function rulesButton()
{
  var modal = document.getElementById("myModal");
    modal.style.display = "block";
});

function mostra(id)
{
    if(document.getELementById(id).style.display= 'block')
  document.getELementById(id).style.display= 'none';
  document.getELementById(b+id).style.display= "Mostrar";
  else
  document.getELementById(id).style.display= 'block';
}


